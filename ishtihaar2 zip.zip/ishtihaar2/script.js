/* ── THEME TOGGLE (Dark/Light Mode) ──────────────────── */
const themeToggleBtn = document.getElementById('themeToggle');
const rootElement = document.documentElement;

// 1. Check if user already has a saved preference, or if their OS prefers dark mode
const storedTheme = localStorage.getItem('ishtihar-theme');
const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

if (storedTheme === 'dark' || (!storedTheme && systemPrefersDark)) {
  rootElement.setAttribute('data-theme', 'dark');
}

// 2. Toggle Theme on click
themeToggleBtn.addEventListener('click', () => {
  const currentTheme = rootElement.getAttribute('data-theme');
  
  if (currentTheme === 'dark') {
    rootElement.removeAttribute('data-theme');
    localStorage.setItem('ishtihar-theme', 'light');
  } else {
    rootElement.setAttribute('data-theme', 'dark');
    localStorage.setItem('ishtihar-theme', 'dark');
  }
});


/* ── MOBILE NAV (Event Delegation & Cached Elements) ── */
const toggle = document.getElementById('menuToggle');
const nav = document.getElementById('primary-nav');

toggle.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  toggle.setAttribute('aria-expanded', isOpen);
  toggle.classList.toggle('active', isOpen); 
  document.body.style.overflow = isOpen ? 'hidden' : '';
});

nav.addEventListener('click', (e) => {
  if (e.target.tagName === 'A') {
    nav.classList.remove('open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.classList.remove('active');
    document.body.style.overflow = '';
  }
});

/* ── SCROLL REVEALS ──────────────────────────────────── */
const revealObs = new IntersectionObserver((entries, observer) => {
  entries.forEach(e => {
    if (e.isIntersecting) { 
      e.target.classList.add('in'); 
      observer.unobserve(e.target); 
    }
  });
}, { threshold: 0.08, rootMargin: "0px 0px -50px 0px" });

document.querySelectorAll('.reveal').forEach(el => revealObs.observe(el));

/* ── REDUCED MOTION ──────────────────────────────────── */
if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  document.querySelectorAll('.reveal').forEach(el => el.classList.add('in'));
  
  // Also stop auto-scroll carousel for accessibility
  const carousel = document.querySelector('.carousel-track');
  if (carousel) carousel.style.animation = 'none';
}